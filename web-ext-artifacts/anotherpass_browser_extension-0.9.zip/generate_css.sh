sass --watch ./scss/custom.scss ./css/custom.css

